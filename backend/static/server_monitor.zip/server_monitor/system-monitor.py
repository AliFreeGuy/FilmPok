import os
import requests
import psutil
import logging
import time

class SystemMonitor:
    def __init__(self):
        self.setup_logging()
        self.net_io_start = psutil.net_io_counters()
        self.ip_server = os.getenv('IP_SERVER', '127.0.0.1')
        self.api_url = os.getenv('API_URL', 'http://127.0.0.1:8000/api/server-monitoring/')
        self.auth_token = os.getenv('AUTH_TOKEN', 'c5cd73397e759e412c1d797de5435a78ebeff933') 

    def setup_logging(self):
        log_filename = 'system_monitor.log'
        log_file_path = os.path.join(os.getcwd(), log_filename)

        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file_path),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger()

    def get_cpu_usage(self):
        """Returns the CPU usage percentage."""
        try:
            return round(psutil.cpu_percent(interval=1), 2)
        except Exception as e:
            self.logger.error(f"Failed to get CPU usage: {str(e)}")
            return None
    
    def get_ram_usage(self):
        """Returns the used RAM in megabytes."""
        try:
            mem = psutil.virtual_memory()
            return round(mem.used / (1024 * 1024), 2)  # Convert bytes to MB and round to 2 decimal places
        except Exception as e:
            self.logger.error(f"Failed to get RAM usage: {str(e)}")
            return None

    def get_network_traffic(self):
        """Returns the total network traffic in megabytes since system start."""
        try:
            net_io_current = psutil.net_io_counters()
            bytes_sent = net_io_current.bytes_sent
            bytes_recv = net_io_current.bytes_recv
            total_traffic_sent = bytes_sent / (1024 * 1024)  
            total_traffic_recv = bytes_recv / (1024 * 1024)  
            total_traffic = round(total_traffic_sent + total_traffic_recv, 2)  # Round to 2 decimal places
            return total_traffic
        except Exception as e:
            self.logger.error(f"Failed to get network traffic: {str(e)}")
            return None

    def log_system_info(self):
        """Logs the CPU usage, RAM usage, and total network traffic and sends the data to the API."""
        try:
            cpu_usage = self.get_cpu_usage()
            ram_usage = self.get_ram_usage()
            total_traffic = self.get_network_traffic()
            
            if cpu_usage is not None:
                self.logger.info(f"CPU Usage: {cpu_usage}%")
            if ram_usage is not None:
                self.logger.info(f"RAM Usage: {ram_usage:.2f} MB")
            if total_traffic is not None:
                self.logger.info(f"Total Network Traffic: {total_traffic:.2f} MB")
            
            self.logger.info(f"Server IP: {self.ip_server}\n")
            
            data = {
                'ip': self.ip_server,
                'traffic_usage': total_traffic,
                'cpu_usage': cpu_usage,
                'memory_usage': ram_usage
            }
            headers = {
                'Authorization': f'token {self.auth_token}'
            }
            response = requests.post(self.api_url, json=data, headers=headers)
            
            if response.status_code == 200:
                self.logger.info(f"Data sent successfully: {response.json()}")
            else:
                self.logger.error(f"Failed to send data: {response.status_code}")

        except Exception as e:
            self.logger.error(f"Failed to log system info: {str(e)}")

    def start_monitoring(self, interval=10):
        """Starts monitoring system info at a specified interval in seconds."""
        while True:
            try:
                self.log_system_info()
            except Exception as e:
                self.logger.error(f"Error during monitoring: {str(e)}")
            time.sleep(interval)

if __name__ == "__main__":
    monitor = SystemMonitor()
    monitor.start_monitoring(interval=10)
