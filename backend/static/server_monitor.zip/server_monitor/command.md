docker build -t system-monitor-image .

docker run -d \
  -e IP_SERVER="0.0.0.0" \
  -e API_URL="http://127.0.0.1:8000/api/server-monitoring/" \
  -e AUTH_TOKEN="c5cd73397e759e412c1d797de5435a78ebeff933" \
  --name system-monitor \
  system-monitor-image