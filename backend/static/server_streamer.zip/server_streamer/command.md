docker run  --restart unless-stopped --name -d fsb \
-e API_ID=26528159 \
-e API_HASH=574a1f892a6c5a816dc611fb931bd828 \
-e BOT_TOKEN=6273067536:AAF7snU34bPkCRwKxVow-qDRYhjtg5ya_fg \
-e MULTI_TOKEN1=6273067536:AAF7snU34bPkCRwKxVow-qDRYhjtg5ya_fg \
-e MULTI_TOKEN2=6273067536:AAF7snU34bPkCRwKxVow-qDRYhjtg5ya_fg \
-e MULTI_TOKEN3=6273067536:AAF7snU34bPkCRwKxVow-qDRYhjtg5ya_fg \
-e BIN_CHANNEL=-1002159744274 \
-e PORT=80 \
-e FQDN=91.107.246.207 \
-e HAS_SSL=False \
-p 80:80 \
stream-bot




