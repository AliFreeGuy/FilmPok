import time
from .vars import Var
from WebStreamer.bot.clients import StreamBot

__version__ = "2.2.4"
StartTime = time.time()
